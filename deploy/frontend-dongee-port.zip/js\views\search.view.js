/**
 * Advanced Search View
 * Search invoices with multiple filters
 */

import { get } from '../services/api.service.js';
import { showToast, showSuccess, showError } from '../components/toast.js';
import { CONFIG, CONSTANTS } from '../config/config.js';
import { formatCurrency, formatDate, getEstadoBadgeColor } from '../utils/formatters.js';
import { navigateTo } from '../utils/router.js';
import { createPagination, attachPaginationListeners, getPaginatedItems } from '../components/pagination.js';

let providers = [];
let searchResults = [];
let currentPage = 1;
let pageSize = 10;

/**
 * Render advanced search view
 * @param {HTMLElement} container - Container element
 */
export async function renderAdvancedSearchView(container) {
    container.innerHTML = `
        <div class="mb-xl">
            <h1>Búsqueda Avanzada</h1>
            <p class="welcome-subtitle">Encuentra facturas usando filtros avanzados</p>
        </div>

        <!-- Search Filters Card -->
        <div class="card mb-xl">
            <div class="card-body">
                <h3 style="margin-bottom: var(--spacing-lg);">Filtros de Búsqueda</h3>
                
                <form id="searchForm">
                    <div class="grid grid-cols-3">
                        <!-- Invoice Number -->
                        <div class="form-group">
                            <label class="form-label">Número de Factura</label>
                            <input type="text" class="form-input" id="numeroFactura" placeholder="Ej: FAC-2024-001">
                        </div>

                        <!-- Provider -->
                        <div class="form-group">
                            <label class="form-label">Proveedor</label>
                            <select class="form-select" id="proveedor">
                                <option value="">Todos los proveedores</option>
                            </select>
                        </div>

                        <!-- Provider NIT -->
                        <div class="form-group">
                            <label class="form-label">NIT del Proveedor</label>
                            <input type="text" class="form-input" id="nitProveedor" placeholder="Ej: 900123456-7">
                        </div>

                        <!-- Status -->
                        <div class="form-group">
                            <label class="form-label">Estado</label>
                            <select class="form-select" id="estado">
                                <option value="">Todos los estados</option>
                                <option value="RUTA_1">Devuelta (En Gestión)</option>
                                <option value="RUTA_2_DIRECCION_ADMINISTRATIVA">Dirección Administrativa</option>
                                <option value="RUTA_2_DIRECCION_FINANCIERA">Dirección Financiera</option>
                                <option value="RUTA_2_DIRECCION_MEDICA">Dirección Médica</option>
                                <option value="RUTA_2_DIRECCION_GENERAL">Dirección General</option>
                                <option value="RUTA_2_CONTROL_INTERNO">Control Interno</option>
                                <option value="RUTA_3">Contabilidad</option>
                                <option value="RUTA_4">Tesorería</option>
                                <option value="ANULADA">Anulada</option>
                                <option value="FINALIZADA">Pagada</option>
                            </select>
                        </div>

                        <!-- Usuario Factura -->
                        <div class="form-group">
                            <label class="form-label">Usuario Factura</label>
                            <select class="form-select" id="usuarioFactura">
                                <option value="">Todos los usuarios</option>
                            </select>
                        </div>

                        <!-- Approval Direction Filter -->
                        <div class="form-group">
                            <label class="form-label">Dirección que Aprobó</label>
                            <select class="form-select" id="direccionAprobo">
                                <option value="">Todas las direcciones</option>
                                <option value="RUTA_2_DIRECCION_ADMINISTRATIVA">Dirección Administrativa</option>
                                <option value="RUTA_2_DIRECCION_FINANCIERA">Dirección Financiera</option>
                                <option value="RUTA_2_DIRECCION_MEDICA">Dirección Médica</option>
                                <option value="RUTA_2_DIRECCION_GENERAL">Dirección General</option>
                                <option value="RUTA_3_CONTROL_INTERNO">Control Interno</option>
                                <option value="RUTA_3">Contabilidad</option>
                                <option value="RUTA_4">Tesorería</option>
                            </select>
                        </div>

                        <!-- Date From -->
                        <div class="form-group">
                            <label class="form-label">Fecha Desde</label>
                            <input type="date" class="form-input" id="fechaDesde">
                        </div>

                        <!-- Date To -->
                        <div class="form-group">
                            <label class="form-label">Fecha Hasta</label>
                            <input type="date" class="form-input" id="fechaHasta">
                        </div>

                        <!-- Amount From -->
                        <div class="form-group">
                            <label class="form-label">Monto Desde</label>
                            <input type="number" class="form-input" id="montoDesde" placeholder="0" min="0" step="0.01">
                        </div>

                        <!-- Amount To -->
                        <div class="form-group">
                            <label class="form-label">Monto Hasta</label>
                            <input type="number" class="form-input" id="montoHasta" placeholder="0" min="0" step="0.01">
                        </div>

                        <!-- Search Buttons -->
                        <div class="form-group" style="display: flex; align-items: flex-end; gap: 0.5rem;">
                            <button type="submit" class="btn btn-primary" style="flex: 1;">
                                🔍 Buscar
                            </button>
                            <button type="button" class="btn btn-secondary" id="btnClearFilters" style="flex: 1;">
                                🔄 Limpiar
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Results Card -->
        <div class="card">
            <div class="card-body">
                <div class="flex justify-between items-center mb-lg">
                    <h3 style="margin: 0;">Resultados de Búsqueda</h3>
                    <div style="display: flex; gap: 1rem; align-items: center;">
                        <span id="resultsCount" class="badge badge-primary">0 resultados</span>
                        <button id="exportExcelBtn" class="btn btn-success btn-sm" style="display: none;">
                            📥 Exportar a Excel
                        </button>
                    </div>
                </div>

                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Número</th>
                                <th>Proveedor</th>
                                <th>Fecha</th>
                                <th>Monto</th>
                                <th>Usuario Factura</th>
                                <th>Estado</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="resultsTableBody">
                            <tr>
                                <td colspan="7" class="text-center" style="color: var(--gray-400);">
                                    Utiliza los filtros para buscar facturas
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!-- Pagination Controls -->
                <div id="searchPaginationContainer"></div>
            </div>
        </div>
    `;

    // Load providers and users for dropdowns
    await loadProviders();
    await loadUsers();

    // Attach event listeners
    document.getElementById('searchForm')?.addEventListener('submit', handleSearch);
    document.getElementById('btnClearFilters')?.addEventListener('click', clearFilters);
    document.getElementById('exportExcelBtn')?.addEventListener('click', exportToExcel);
}

/**
 * Load providers for dropdown
 */
async function loadProviders() {
    try {
        const response = await get('/proveedores');
        providers = response.proveedores || response || [];

        const select = document.getElementById('proveedor');
        if (select && providers.length > 0) {
            providers.forEach(provider => {
                const option = document.createElement('option');
                option.value = provider.id;
                option.textContent = `${provider.nombre} (${provider.nit})`;
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error loading providers:', error);
    }
}

/**
 * Load RUTA_1 users for dropdown
 */
async function loadUsers() {
    try {
        const response = await get('/usuarios/ruta1');
        const users = response.usuarios || [];

        const select = document.getElementById('usuarioFactura');
        if (select && users.length > 0) {
            users.forEach(user => {
                const option = document.createElement('option');
                option.value = user.usuario_id;
                option.textContent = user.nombre;
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

/**
 * Handle search form submission
 */
async function handleSearch(e) {
    e.preventDefault();

    const filters = {
        numero_factura: document.getElementById('numeroFactura').value.trim(),
        proveedor_id: document.getElementById('proveedor').value,
        nit: document.getElementById('nitProveedor').value.trim(),
        estado: document.getElementById('estado').value,
        direccion_aprobo: document.getElementById('direccionAprobo').value,
        usuario_creacion_id: document.getElementById('usuarioFactura').value,
        fecha_desde: document.getElementById('fechaDesde').value,
        fecha_hasta: document.getElementById('fechaHasta').value,
        monto_desde: document.getElementById('montoDesde').value,
        monto_hasta: document.getElementById('montoHasta').value
    };

    // Remove empty filters
    Object.keys(filters).forEach(key => {
        if (!filters[key]) delete filters[key];
    });

    try {
        // Build query string (can be empty to fetch all)
        const queryString = new URLSearchParams(filters).toString();
        const endpoint = queryString ? `/facturas/busqueda-avanzada?${queryString}` : '/facturas/busqueda-avanzada';
        const response = await get(endpoint);

        searchResults = response.facturas || response || [];
        renderResults();

        if (searchResults.length === 0) {
            showToast('Info', 'No se encontraron facturas con los filtros especificados', 'info');
        } else {
            showSuccess('Éxito', `Se encontraron ${searchResults.length} factura(s)`);
        }
    } catch (error) {
        console.error('Error searching invoices:', error);
        showError('Error', error.message || 'No se pudo realizar la búsqueda');
        searchResults = [];
        renderResults();
    }
}

/**
 * Render search results
 */
function renderResults() {
    const tbody = document.getElementById('resultsTableBody');
    const countBadge = document.getElementById('resultsCount');
    const exportBtn = document.getElementById('exportExcelBtn');

    if (!tbody) return;

    // Update count
    if (countBadge) {
        countBadge.textContent = `${searchResults.length} resultado${searchResults.length !== 1 ? 's' : ''}`;
    }

    // Show/hide export button
    if (exportBtn) {
        exportBtn.style.display = searchResults.length > 0 ? 'inline-block' : 'none';
    }

    if (searchResults.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center" style="color: var(--gray-400);">
                    No se encontraron resultados
                </td>
            </tr>
        `;
        document.getElementById('searchPaginationContainer').innerHTML = '';
        return;
    }

    // Reset to first page when search results change
    if (currentPage > Math.ceil(searchResults.length / pageSize)) {
        currentPage = 1;
    }

    renderSearchResultsPage();
}

/**
 * Render current page of search results
 */
function renderSearchResultsPage() {
    const tbody = document.getElementById('resultsTableBody');
    const paginationContainer = document.getElementById('searchPaginationContainer');

    // Get paginated items
    const paginatedResults = getPaginatedItems(searchResults, currentPage, pageSize);

    tbody.innerHTML = paginatedResults.map(factura => {
        const badgeColor = getEstadoBadgeColor(factura.estado_codigo);
        const estadoLabel = CONSTANTS.ESTADO_LABELS[factura.estado_codigo] || factura.estado_nombre || 'Sin estado';

        return `
            <tr>
                <td><strong>${factura.numero_factura}</strong></td>
                <td>${factura.proveedor_nombre || '-'}</td>
                <td>${formatDate(factura.fecha_emision || factura.fecha_creacion)}</td>
                <td><strong>${formatCurrency(factura.monto)}</strong></td>
                <td>${factura.usuario_creacion_nombre || '-'}</td>
                <td>
                    <span class="badge badge-${badgeColor}">
                        ${estadoLabel}
                    </span>
                </td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="window.viewInvoiceDetail(${factura.factura_id})">
                        👁️ Ver
                    </button>
                </td>
            </tr>
        `;
    }).join('');

    // Render pagination controls
    paginationContainer.innerHTML = createPagination({
        currentPage,
        pageSize,
        totalItems: searchResults.length,
        onPageChange: handleSearchPageChange,
        onPageSizeChange: handleSearchPageSizeChange
    });

    // Attach pagination event listeners
    attachPaginationListeners(handleSearchPageChange, handleSearchPageSizeChange);
}

/**
 * Handle page change for search results
 * @param {number|string} page - Page number or 'prev'/'next'/'last'
 */
function handleSearchPageChange(page) {
    const totalPages = Math.ceil(searchResults.length / pageSize);

    if (page === 'prev') {
        currentPage = Math.max(1, currentPage - 1);
    } else if (page === 'next') {
        currentPage = Math.min(totalPages, currentPage + 1);
    } else if (page === 'last') {
        currentPage = totalPages;
    } else {
        currentPage = page;
    }

    renderSearchResultsPage();
}

/**
 * Handle page size change for search results
 * @param {number} newPageSize - New page size
 */
function handleSearchPageSizeChange(newPageSize) {
    pageSize = newPageSize;
    currentPage = 1; // Reset to first page
    renderSearchResultsPage();
}

/**
 * Clear all filters
 */
function clearFilters() {
    document.getElementById('searchForm').reset();
    searchResults = [];
    renderResults();

    const countBadge = document.getElementById('resultsCount');
    if (countBadge) {
        countBadge.textContent = '0 resultados';
    }

    const tbody = document.getElementById('resultsTableBody');
    if (tbody) {
        tbody.innerHTML = `
            <tr>
                <td colspan="6" class="text-center" style="color: var(--gray-400);">
                    Utiliza los filtros para buscar facturas
                </td>
            </tr>
        `;
    }
}

/**
 * Export search results to Excel
 */
async function exportToExcel() {
    try {
        const exportBtn = document.getElementById('exportExcelBtn');
        const originalText = exportBtn.textContent;

        // Disable button and show loading
        exportBtn.disabled = true;
        exportBtn.textContent = '⏳ Exportando...';

        // Get current search filters - SAME AS handleSearch
        const filters = {
            numero_factura: document.getElementById('numeroFactura')?.value.trim() || '',
            proveedor_id: document.getElementById('proveedor')?.value || '',
            nit: document.getElementById('nitProveedor')?.value.trim() || '',
            estado: document.getElementById('estado')?.value || '',
            direccion_aprobo: document.getElementById('direccionAprobo')?.value || '',
            usuario_creacion_id: document.getElementById('usuarioFactura')?.value || '',
            fecha_desde: document.getElementById('fechaDesde')?.value || '',
            fecha_hasta: document.getElementById('fechaHasta')?.value || '',
            monto_desde: document.getElementById('montoDesde')?.value || '',
            monto_hasta: document.getElementById('montoHasta')?.value || ''
        };

        // Remove empty filters
        Object.keys(filters).forEach(key => {
            if (!filters[key]) delete filters[key];
        });

        // Make request to export endpoint
        const response = await fetch(`${CONFIG.API_BASE_URL}/export/facturas`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
            },
            body: JSON.stringify(filters)
        });

        if (!response.ok) {
            throw new Error('Error al exportar a Excel');
        }

        // Get filename from response headers or use default
        const contentDisposition = response.headers.get('Content-Disposition');
        let filename = 'Facturas.xlsx';
        if (contentDisposition) {
            const matches = /filename="([^"]+)"/.exec(contentDisposition);
            if (matches && matches[1]) {
                filename = matches[1];
            }
        }

        // Download file
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.URL.revokeObjectURL(url);

        showSuccess('Éxito', 'Archivo Excel descargado correctamente');

    } catch (error) {
        console.error('Error exporting to Excel:', error);
        showError('Error', 'No se pudo exportar a Excel');
    } finally {
        // Re-enable button
        const exportBtn = document.getElementById('exportExcelBtn');
        if (exportBtn) {
            exportBtn.disabled = false;
            exportBtn.textContent = '📥 Exportar a Excel';
        }
    }
}

// Make function global for inline onclick
window.viewInvoiceDetail = function (id) {
    navigateTo(`factura/${id}`);
};
